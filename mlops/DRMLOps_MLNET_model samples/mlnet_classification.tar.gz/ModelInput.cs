//*****************************************************************************************
//*                                                                                       *
//* This is an auto-generated file by Microsoft ML.NET CLI (Command-Line Interface) tool. *
//*                                                                                       *
//*****************************************************************************************

using Microsoft.ML.Data;

namespace DataRobot.Model.DataModels
{
    public class ModelInput
    {
        [ColumnName("loan_amnt"), LoadColumn(0)]
        public float Loan_amnt { get; set; }


        [ColumnName("funded_amnt"), LoadColumn(1)]
        public float Funded_amnt { get; set; }


        [ColumnName("term"), LoadColumn(2)]
        public string Term { get; set; }


        [ColumnName("int_rate"), LoadColumn(3)]
        public string Int_rate { get; set; }


        [ColumnName("installment"), LoadColumn(4)]
        public float Installment { get; set; }


        [ColumnName("grade"), LoadColumn(5)]
        public string Grade { get; set; }


        [ColumnName("sub_grade"), LoadColumn(6)]
        public string Sub_grade { get; set; }


        [ColumnName("emp_title"), LoadColumn(7)]
        public string Emp_title { get; set; }


        [ColumnName("emp_length"), LoadColumn(8)]
        public string Emp_length { get; set; }


        [ColumnName("home_ownership"), LoadColumn(9)]
        public string Home_ownership { get; set; }


        [ColumnName("annual_inc"), LoadColumn(10)]
        public float Annual_inc { get; set; }


        [ColumnName("verification_status"), LoadColumn(11)]
        public string Verification_status { get; set; }


        [ColumnName("pymnt_plan"), LoadColumn(12)]
        public bool Pymnt_plan { get; set; }


        [ColumnName("url"), LoadColumn(13)]
        public string Url { get; set; }


        [ColumnName("desc"), LoadColumn(14)]
        public string Desc { get; set; }


        [ColumnName("purpose"), LoadColumn(15)]
        public string Purpose { get; set; }


        [ColumnName("title"), LoadColumn(16)]
        public string Title { get; set; }


        [ColumnName("zip_code"), LoadColumn(17)]
        public string Zip_code { get; set; }


        [ColumnName("addr_state"), LoadColumn(18)]
        public string Addr_state { get; set; }


        [ColumnName("dti"), LoadColumn(19)]
        public float Dti { get; set; }


        [ColumnName("delinq_2yrs"), LoadColumn(20)]
        public float Delinq_2yrs { get; set; }


        [ColumnName("earliest_cr_line"), LoadColumn(21)]
        public string Earliest_cr_line { get; set; }


        [ColumnName("inq_last_6mths"), LoadColumn(22)]
        public float Inq_last_6mths { get; set; }


        [ColumnName("mths_since_last_delinq"), LoadColumn(23)]
        public float Mths_since_last_delinq { get; set; }


        [ColumnName("mths_since_last_record"), LoadColumn(24)]
        public float Mths_since_last_record { get; set; }


        [ColumnName("open_acc"), LoadColumn(25)]
        public float Open_acc { get; set; }


        [ColumnName("pub_rec"), LoadColumn(26)]
        public float Pub_rec { get; set; }


        [ColumnName("revol_bal"), LoadColumn(27)]
        public float Revol_bal { get; set; }


        [ColumnName("revol_util"), LoadColumn(28)]
        public float Revol_util { get; set; }


        [ColumnName("total_acc"), LoadColumn(29)]
        public float Total_acc { get; set; }


        [ColumnName("initial_list_status"), LoadColumn(30)]
        public bool Initial_list_status { get; set; }


        [ColumnName("mths_since_last_major_derog"), LoadColumn(31)]
        public float Mths_since_last_major_derog { get; set; }


        [ColumnName("policy_code"), LoadColumn(32)]
        public float Policy_code { get; set; }


        [ColumnName("is_bad"), LoadColumn(33)]
        public bool Is_bad { get; set; }


    }
}