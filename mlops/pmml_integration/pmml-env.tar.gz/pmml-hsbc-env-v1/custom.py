import pandas as pd


def predict(data, model, positive_class_label=None, negative_class_label=None, **kwargs):
    """
    Modify this method to add pre and post processing for scoring calls.  For example, this can be
    used to implement one-hot encoding for models that don't include it on their own.

    Parameters
    ----------
    data: pd.DataFrame
    model_predict: Callable[[pd.DataFrame], pd.DataFrame]

    Returns
    -------
    pd.DataFrame
    """
    print(model)
    print(positive_class_label)
    print(negative_class_label)

    print(str(data))
    print(str(data.shape))

    result = model.predict(data)

    cols = ["predicted_class", "probability"]

    result = result[cols]

    #preds_df = preds_df.rename(columns = {"p_np": "positive_class_label"})
    #preds_df = preds_df.drop(columns=['smiles'])
    #preds_df["negative_class_label"] = 1 - preds_df["positive_class_label"]

    print(str(result))

    # Execute any steps you need to do after scoring
    # Note: To properly send predictions back to DataRobot, the returned DataFrame should contain a
    # column for each output label for classification or a single value column for regression
    return result

def _predict(data, model_predict):
    """
    Modify this method to add pre and post processing for scoring calls.  For example, this can be
    used to implement one-hot encoding for models that don't include it on their own.

    Parameters
    ----------
    data: pd.DataFrame
    model_predict: Callable[[pd.DataFrame], pd.DataFrame]

    Returns
    -------
    pd.DataFrame
    """
    # Execute any steps you need to do before scoring

    # This method makes predictions against the raw, deserialized model
    #predictions = model_predict(data)

    #data.to_csv("/opt/code/chemprop_folder/for_scoring.csv", index=False)

    keywords = model_predict.keywords
    print(keywords)
    print(keywords["model"])
    print(keywords["positive_class_label"])
    print(keywords["negative_class_label"])

    print("predict")
    print(str(data))

    result = model.predict(data)

    # Execute any steps you need to do after scoring
    # Note: To properly send predictions back to DataRobot, the returned DataFrame should contain a
    # column for each output label for classification or a single value column for regression
    return result
